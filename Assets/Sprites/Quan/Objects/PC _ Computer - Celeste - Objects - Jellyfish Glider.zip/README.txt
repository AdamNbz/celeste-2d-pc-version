The Raw folder contains all raw jellyfish sprites with the original filenames from the game's meta files.
The Animations folder contains all animations with their original names from the game's animation xml files, divided as individual frames and as a gif file.

Do note, the animations are made out of the raw sprites, but not all raw sprites are necessarely used in animations.

Credits to EXOK if these sprites are used.